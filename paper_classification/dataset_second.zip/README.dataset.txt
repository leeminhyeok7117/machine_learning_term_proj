# airplane_class > 2025-06-07 6:48am
https://universe.roboflow.com/minhyeoklee/airplane_class

Provided by a Roboflow user
License: CC BY 4.0

