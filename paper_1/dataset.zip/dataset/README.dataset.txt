# paper_classification > 2025-06-06 11:37pm
https://universe.roboflow.com/minhyeoklee/paper_classification

Provided by a Roboflow user
License: CC BY 4.0

